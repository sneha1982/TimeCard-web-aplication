function myFunction1() {
    alert("You have clocked in!");
}

function myFunction2() {
    alert("You have clocked out!");
}