'use strict';

const express = require('express');

const path = require('path');
const config = require('./config');
var mustache = require("mustache");
var fs = require("fs");

const app = express();

app.use('/public', express.static('public'));

var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

// Get the data model for "employees"
function getModel () {
	return require(`./employees/model-${config.get('DATA_BACKEND')}`);
}

function getTransactionsModel() {
    return require(`./transactions/model-${config.get('DATA_BACKEND')}`);
}

app.set('views', path.join(__dirname, 'views'));

//Redirect root to /employees
app.get('/', (req, res) => {
  res.redirect('/employees');
});

app.get('/employees', (req, res) => {
    var page = fs.readFileSync("views/login.html.mustache").toString();
    var html = mustache.render(page);
    res.status(200).send(html);
});

// app.get('/employees', (req, res, next) => {
	// var pageToken = (req.query.pageToken == 'false') ? false : req.query.pageToken;
	// getModel().list(10, pageToken, (err, entities, cursor) => {
	// 	    if (err) {
	// 	      next(err);
	// 	      return;
	// 	    }
	// 	    var page = fs.readFileSync("views/login.html.mustache").toString();
	// 	    console.log(cursor)
	// 	    var html = mustache.render(page, { employees: entities, next_page_token: cursor});
	// 	    res.status(200).send(html);
	// 	  });
	// 	});

app.get('/employees/logon', (req, res) => {
    var page = fs.readFileSync("views/profile.html.mustache").toString();
    var html = mustache.render(page, { employee: {}});
    res.status(200).send(html);
});

app.get('/employees/logout', (req, res) => {
    var page = fs.readFileSync("views/login.html.mustache").toString();
    var html = mustache.render(page);
    res.status(200).send(html);
});

app.get('/employees/register', (req, res) => {
    var page = fs.readFileSync("views/register.html.mustache").toString();
    var html = mustache.render(page, {employee: {}});
    res.status(200).send(html);
});
// /**
//  * POST /employees/:id/edit
//  *
//  * Update a employee.
//  */
// app.post('/employees/register', (req, res, next) => {
//     const data = req.body;
//
// getModel().update(req.params.employee, data, (err) => {
//     if (err) {
//         next(err);
//         return;
//     }
//     res.redirect('views/login.html.mustache');
// });
// });

app.get('/employees/manage', (req, res, next) => {
    var pageToken = (req.query.pageToken == 'false') ? false : req.query.pageToken;
getModel().list(10, pageToken, (err, entities, cursor) => {
    if(err) {
        next(err);
        return;
    }
    var page = fs.readFileSync("views/management.html.mustache").toString();
console.log(cursor)
var html = mustache.render(page, {employees: entities, next_page_token: cursor});
res.status(200).send(html);
});
});

app.get('/employees/clockin-out', (req, res) => {
    var page = fs.readFileSync("views/clockin.html.mustache").toString();
    var html = mustache.render(page);
    res.status(200).send(html);
});
// app.post('/employees/clockin-out', (req, res, next) => {
//     const data = req.body;
//
// // Save the data to the database.
// getTransactionsModel().create(data, (err) => {
//     if(err) {
//         next(err);
//         return;
//     }
//     res.redirect('/employees/clockin-out');
// });
// });

app.get('/employees/id', (req, res) => {
    var page = fs.readFileSync("views/id.html.mustache").toString();
var html = mustache.render(page, { transactions: {}});
res.status(200).send(html);
});

app.get('/employees/:transaction/record', (req, res, next) => {
    getTransactionsModel().read(req.params.transactions, (err, entities) => {
    if (err) {
        next(err);
        return;
    }
    var page = fs.readFileSync("views/record.html.mustache").toString();
var html = mustache.render(page, { transactions: entities });
res.status(200).send(html);
});
});

app.get('/employees/add', (req, res) => {
    var page = fs.readFileSync("views/homepage.html.mustache").toString();
    var html = mustache.render(page, {employee: {}, action: 'Add'});
    res.status(200).send(html);
});

app.post('/employees/add', (req, res, next) => {
	  const data = req.body;

	  // Save the data to the database.
	  getModel().create(data, (err) => {
	    if (err) {
	      next(err);
	      return;
	    }
          res.redirect('/employees/manage');
	  });
	});

/**
 * GET /employees/:id/edit
 *
 * Display an employee for editing.
 */
app.get('/employees/:employee/edit', (req, res, next) => {
  getModel().read(req.params.employee, (err, entities) => {
    if (err) {
      next(err);
      return;
    }
    var page = fs.readFileSync("views/homepage.html.mustache").toString();
    var html = mustache.render(page, { employee: entities, action: 'Edit'});
    res.status(200).send(html);
  });
});


/**
 * GET /employees/:id
 *
 * Display an employee.
 */
// app.get('/employees/:employee', (req, res, next) => {
//   getModel().read(req.params.employee, (err, entity) => {
//     if (err) {
//       next(err);
//       return;
//     }
//     var page = fs.readFileSync("views/view.html.mustache").toString();
//     var html = mustache.render(page, { employee: entity});
//     res.status(200).send(html);
//   });
// });

/**
 * POST /employees/:id/edit
 *
 * Update a employee.
 */
app.post('/employees/:employee/edit', (req, res, next) => {
  const data = req.body;

  getModel().update(req.params.employee, data, (err) => {
    if (err) {
      next(err);
      return;
    }
      res.redirect('/employees/manage');
  });
});

/**
 * GET /employees/:id/delete
 *
 * Delete an employee.
 */
app.get('/employees/:employee/delete', (req, res, next) => {
    getModel().delete(req.params.employee, (err) => {
    if (err) {
        next(err);
        return;
    }
    res.redirect('/employees/manage');
});
});


if (module === require.main) {
  // [START server]
  // Start the server
  const server = app.listen(process.env.PORT || 8081, () => {
    const port = server.address().port;
    console.log(`App listening on port ${port}`);
  });
  // [END server]
}

module.exports = app;